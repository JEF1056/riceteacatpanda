import subprocess
arg = 'f'*10000
subprocess.call(["Portal.exe",arg])